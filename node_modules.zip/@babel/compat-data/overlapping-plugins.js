module.exports = require("./data/overlapping-plugins.json");
