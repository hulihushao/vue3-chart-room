# @babel/compat-data

> 

See our website [@babel/compat-data](https://babeljs.io/docs/babel-compat-data) for more information.

## Install

Using npm:

```sh
npm install --save @babel/compat-data
```

or using yarn:

```sh
yarn add @babel/compat-data
```
