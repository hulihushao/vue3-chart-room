import { chain } from "lodash";
export default chain;
