import { isNil } from "lodash";
export default isNil;
