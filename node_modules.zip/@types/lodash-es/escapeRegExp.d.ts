import { escapeRegExp } from "lodash";
export default escapeRegExp;
