import { curry } from "lodash";
export default curry;
