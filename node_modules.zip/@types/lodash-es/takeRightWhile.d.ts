import { takeRightWhile } from "lodash";
export default takeRightWhile;
