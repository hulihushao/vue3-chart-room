import { last } from "lodash";
export default last;
