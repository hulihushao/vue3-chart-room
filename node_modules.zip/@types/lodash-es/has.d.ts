import { has } from "lodash";
export default has;
