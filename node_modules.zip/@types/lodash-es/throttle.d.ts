import { throttle, ThrottleSettings } from "lodash";

export { ThrottleSettings };
export default throttle;
