import { isNull } from "lodash";
export default isNull;
