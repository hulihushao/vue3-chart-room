import { result } from "lodash";
export default result;
