import { fromPairs } from "lodash";
export default fromPairs;
