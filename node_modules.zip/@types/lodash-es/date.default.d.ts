import now from "./now";

declare const defaultExport: {
  now: typeof now;
};
export default defaultExport;
