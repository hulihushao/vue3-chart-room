import { slice } from "lodash";
export default slice;
