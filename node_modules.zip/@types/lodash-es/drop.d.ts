import { drop } from "lodash";
export default drop;
