import { bindKey } from "lodash";
export default bindKey;
