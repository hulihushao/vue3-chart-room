import { isString } from "lodash";
export default isString;
