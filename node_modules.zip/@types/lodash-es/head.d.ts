import { head } from "lodash";
export default head;
