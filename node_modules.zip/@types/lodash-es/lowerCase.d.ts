import { lowerCase } from "lodash";
export default lowerCase;
