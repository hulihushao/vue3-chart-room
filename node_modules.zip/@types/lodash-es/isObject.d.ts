import { isObject } from "lodash";
export default isObject;
