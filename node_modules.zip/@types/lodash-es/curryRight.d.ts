import { curryRight } from "lodash";
export default curryRight;
