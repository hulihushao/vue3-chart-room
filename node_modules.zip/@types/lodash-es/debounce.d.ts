import { debounce, DebouncedFunc, DebounceSettings } from "lodash";

export { DebounceSettings, DebouncedFunc };
export default debounce;
