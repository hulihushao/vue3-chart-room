import { multiply } from "lodash";
export default multiply;
