import { camelCase } from "lodash";
export default camelCase;
