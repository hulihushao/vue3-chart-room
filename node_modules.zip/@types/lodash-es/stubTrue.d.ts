import { stubTrue } from "lodash";
export default stubTrue;
