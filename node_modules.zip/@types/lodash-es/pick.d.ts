import { pick } from "lodash";
export default pick;
