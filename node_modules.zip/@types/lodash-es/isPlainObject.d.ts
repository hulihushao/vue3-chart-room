import { isPlainObject } from "lodash";
export default isPlainObject;
