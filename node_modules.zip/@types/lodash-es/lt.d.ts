import { lt } from "lodash";
export default lt;
