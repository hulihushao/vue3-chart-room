import { invokeMap } from "lodash";
export default invokeMap;
