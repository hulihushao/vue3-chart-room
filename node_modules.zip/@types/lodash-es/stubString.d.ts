import { stubString } from "lodash";
export default stubString;
