import { kebabCase } from "lodash";
export default kebabCase;
