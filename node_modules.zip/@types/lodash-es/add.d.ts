import { add } from "lodash";
export default add;
