import { isWeakMap } from "lodash";
export default isWeakMap;
