import { each } from "lodash";
export default each;
