import { toLower } from "lodash";
export default toLower;
