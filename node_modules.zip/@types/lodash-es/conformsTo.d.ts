import { conformsTo } from "lodash";
export default conformsTo;
