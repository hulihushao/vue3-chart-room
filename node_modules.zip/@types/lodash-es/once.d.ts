import { once } from "lodash";
export default once;
