import { isObjectLike } from "lodash";
export default isObjectLike;
