import { every } from "lodash";
export default every;
