import { method } from "lodash";
export default method;
