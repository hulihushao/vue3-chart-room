import { isWeakSet } from "lodash";
export default isWeakSet;
