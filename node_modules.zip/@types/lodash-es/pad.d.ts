import { pad } from "lodash";
export default pad;
