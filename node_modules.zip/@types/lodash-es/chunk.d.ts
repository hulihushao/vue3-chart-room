import { chunk } from "lodash";
export default chunk;
