import { flatMap } from "lodash";
export default flatMap;
