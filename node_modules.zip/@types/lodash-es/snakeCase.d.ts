import { snakeCase } from "lodash";
export default snakeCase;
