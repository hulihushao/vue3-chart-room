import { constant } from "lodash";
export default constant;
