import { clamp } from "lodash";
export default clamp;
