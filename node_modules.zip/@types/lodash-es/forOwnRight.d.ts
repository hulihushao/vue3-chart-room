import { forOwnRight } from "lodash";
export default forOwnRight;
