import { nth } from "lodash";
export default nth;
