import { template } from "lodash";
export default template;
