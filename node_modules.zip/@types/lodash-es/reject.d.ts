import { reject } from "lodash";
export default reject;
