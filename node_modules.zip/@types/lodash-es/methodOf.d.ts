import { methodOf } from "lodash";
export default methodOf;
