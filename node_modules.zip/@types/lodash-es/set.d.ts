import { set } from "lodash";
export default set;
