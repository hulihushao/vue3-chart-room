import { lte } from "lodash";
export default lte;
