import { isError } from "lodash";
export default isError;
