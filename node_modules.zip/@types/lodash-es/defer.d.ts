import { defer } from "lodash";
export default defer;
