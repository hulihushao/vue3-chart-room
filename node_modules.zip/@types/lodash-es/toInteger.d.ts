import { toInteger } from "lodash";
export default toInteger;
