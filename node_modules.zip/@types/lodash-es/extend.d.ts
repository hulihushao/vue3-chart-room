import { extend } from "lodash";
export default extend;
