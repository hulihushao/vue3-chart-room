import { split } from "lodash";
export default split;
