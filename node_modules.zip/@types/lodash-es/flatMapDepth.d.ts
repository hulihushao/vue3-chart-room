import { flatMapDepth } from "lodash";
export default flatMapDepth;
