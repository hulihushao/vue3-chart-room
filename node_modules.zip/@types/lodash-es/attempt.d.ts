import { attempt } from "lodash";
export default attempt;
