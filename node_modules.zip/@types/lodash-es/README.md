# Installation
> `npm install --save @types/lodash-es`

# Summary
This package contains type definitions for lodash-es (http://lodash.com/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/lodash-es.

### Additional Details
 * Last updated: Sun, 06 Feb 2022 20:31:32 GMT
 * Dependencies: [@types/lodash](https://npmjs.com/package/@types/lodash)
 * Global values: none

# Credits
These definitions were written by [Stephen Lautier](https://github.com/stephenlautier), and [e-cloud](https://github.com/e-cloud).
