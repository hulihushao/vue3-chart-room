import { default as now } from "./now";

export { default } from "./date.default";
