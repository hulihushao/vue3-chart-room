import { rangeRight } from "lodash";
export default rangeRight;
