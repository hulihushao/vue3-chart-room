import { isTypedArray } from "lodash";
export default isTypedArray;
