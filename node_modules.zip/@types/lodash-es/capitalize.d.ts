import { capitalize } from "lodash";
export default capitalize;
