import { sample } from "lodash";
export default sample;
