import { tail } from "lodash";
export default tail;
