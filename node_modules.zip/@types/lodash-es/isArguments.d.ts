import { isArguments } from "lodash";
export default isArguments;
