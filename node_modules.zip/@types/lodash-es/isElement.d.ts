import { isElement } from "lodash";
export default isElement;
