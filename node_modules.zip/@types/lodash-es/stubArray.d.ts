import { stubArray } from "lodash";
export default stubArray;
