import { templateSettings } from "lodash";
export default templateSettings;
