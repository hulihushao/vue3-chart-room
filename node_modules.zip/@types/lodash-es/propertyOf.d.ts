import { propertyOf } from "lodash";
export default propertyOf;
