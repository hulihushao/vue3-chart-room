import { ceil } from "lodash";
export default ceil;
