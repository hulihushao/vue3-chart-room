import { isArrayBuffer } from "lodash";
export default isArrayBuffer;
