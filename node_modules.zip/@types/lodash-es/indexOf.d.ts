import { indexOf } from "lodash";
export default indexOf;
