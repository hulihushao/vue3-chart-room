import { isRegExp } from "lodash";
export default isRegExp;
