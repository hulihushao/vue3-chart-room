export declare function getComputedStyle(element: Element): CSSStyleDeclaration;
