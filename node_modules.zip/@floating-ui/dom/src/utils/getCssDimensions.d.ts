import type { Dimensions } from '@floating-ui/core';
export declare function getCssDimensions(element: HTMLElement): Dimensions & {
    fallback: boolean;
};
