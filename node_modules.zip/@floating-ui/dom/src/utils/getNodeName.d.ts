export declare function getNodeName(node: Node | Window): string;
