import type { Alignment } from '../types';
export declare function getAlignment<T extends string>(placement: T): Alignment;
