import { Padding, SideObject } from '../types';
export declare function getSideObjectFromPadding(padding: Padding): SideObject;
