import type { ClientRectObject, Rect } from '../types';
export declare function rectToClientRect(rect: Rect): ClientRectObject;
