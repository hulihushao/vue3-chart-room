import type { SideObject } from '../types';
export declare function expandPaddingObject(padding: Partial<SideObject>): SideObject;
