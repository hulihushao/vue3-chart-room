export declare function within(min: number, value: number, max: number): number;
