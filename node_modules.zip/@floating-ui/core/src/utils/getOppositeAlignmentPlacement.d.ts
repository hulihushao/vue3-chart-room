export declare function getOppositeAlignmentPlacement<T extends string>(placement: T): T;
